export default [
  {
    title: 'Shop for shirts, tees, jeans, hoodies...',
    // image: 'https://source.unsplash.com/lkMJcGDZLVs/840x840',
    image: 'https://images.unsplash.com/photo-1519058082700-08a0b56da9b4?crop=entropy&w=840&h=840&fit=crop',
    price: 180,
    horizontal: true,
  },
  {
    title: "Shop the full collection of men’s...",
    // image: 'https://source.unsplash.com/t3zrEm88ehc/840x840',
    image: 'https://images.unsplash.com/photo-1504593811423-6dd665756598?crop=entropy&w=840&fit=crop',
    price: 220,
  },
  {
    title: "Menswear gets a stylish update...",
    // image: 'https://source.unsplash.com/KhHUkOXQo4k/840x840',
    image: 'https://images.unsplash.com/photo-1489924309280-34282407eca2?crop=entropy&w=840&h=840&fit=crop',
    price: 40,
  },
  {
    title: "Our men's collection focuses on...",
    // image: 'https://source.unsplash.com/6dvxVmG5nUU/840x840',
    image: 'https://images.unsplash.com/photo-1495605952598-956edca588a4?crop=entropy&w=840&h=840&fit=crop',
    price: 188,
    horizontal: true,
  },
  {
    title: 'From latest styles to classic looks, we have it.',
    // image: 'https://source.unsplash.com/HqtYwlY9dxs/840x840',
    image: 'https://images.unsplash.com/photo-1505022610485-0249ba5b3675?crop=entropy&w=840&h=840&fit=crop',
    price: 180,
  },
];