export default tabs = {
  categories: [
    { id: 'popular', title: 'POPULAR' },
    { id: 'beauty', title: 'BEAUTY' },
    { id: 'car_motorcycle', title: 'CAR & MOTORCYCLE' },
  ],
  deals: [
    { id: 'popular', title: 'POPULAR', },
    { id: 'beauty', title: 'BEAUTY', },
    { id: 'cars', title: 'CARS', },
    { id: 'motocycles', title: 'MOTOCYCLES', },
  ],
}