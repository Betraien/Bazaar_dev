export default [
  {
    title: 'Enjoy your every moment of a pillow fight.',
    // image: 'https://source.unsplash.com/dAMvcGb8Vog/840x840',
    image: 'https://images.unsplash.com/photo-1513807016779-d51c0c026263?crop=entropy&w=840&h=840&fit=crop',
    price: 180,
    horizontal: true,
  },
  {
    title: "Everyone is a superhero in their hearts.",
    // image: 'https://source.unsplash.com/Do1GQljlNk8/840x840',
    image: 'https://images.unsplash.com/photo-1519340241574-2cec6aef0c01?crop=entropy&w=840&fit=crop',
    price: 220,
  },
  {
    title: "Yes, I’m a Princess and I like the color Red.",
    // image: 'https://source.unsplash.com/e6lWMBIgNso/840x840',
    image: 'https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?crop=entropy&w=840&h=840&fit=crop',
    price: 40,
  },
  {
    title: "This was the best ice cream I had last summer.",
    // image: 'https://source.unsplash.com/jyb5Ls8JnN0/840x840',
    image: 'https://images.unsplash.com/photo-1502901930015-158e72cff877?crop=entropy&w=840&h=840&fit=crop',
    price: 188,
    horizontal: true,
  },
  {
    title: 'This world is full of hope. Make the most of it!',
    // image: 'https://source.unsplash.com/FtZL0r4DZYk/840x840',
    image: 'https://images.unsplash.com/photo-1489710437720-ebb67ec84dd2?crop=entropy&w=840&h=840&fit=crop',
    price: 180,
  },
];